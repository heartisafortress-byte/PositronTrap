#include "DetectorConstruction.hh"
#include "EMField.hh"

#include "G4Box.hh"
#include "G4Tubs.hh"
#include "G4LogicalVolume.hh"
#include "G4NistManager.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"
#include "G4SDManager.hh"
#include "G4FieldManager.hh"
#include "G4FieldBuilder.hh"
#include "G4GenericMessenger.hh"
#include "G4UniformElectricField.hh"

#include "G4EqMagElectricField.hh"
#include "G4TransportationManager.hh"
#include "G4ChordFinder.hh"
#include "G4ClassicalRK4.hh"
#include "G4EqEMFieldWithSpin.hh"
#include "G4MagIntegratorStepper.hh"
#include "G4PropagatorInField.hh"

G4ThreadLocal EMField* DetectorConstruction::fEMField = nullptr;
G4ThreadLocal G4FieldManager* DetectorConstruction::fFieldMgr = nullptr;

DetectorConstruction::DetectorConstruction(){}

DetectorConstruction::~DetectorConstruction(){}

G4VPhysicalVolume* DetectorConstruction::Construct()
{
  // Get nist material manager
  G4NistManager* nist = G4NistManager::Instance();
  G4Material* Air  = nist->FindOrBuildMaterial("G4_AIR");

  G4double V_AtomicNumber = 1.;
  G4double V_MassOfMole = 1.008*g/mole;
  G4double V_d = 1.e-25*g/cm3;
  G4double V_t = 2.73*kelvin;
  G4double V_p = 3.e-18*pascal;
  G4Material* Vacuum =
      new G4Material("Vacuum", V_AtomicNumber, V_MassOfMole, V_d, kStateGas, V_t, V_p);

  // Target
  G4double innerRadius = 0.*cm;
  G4double tt_outerRadius = 2*cm;
  G4double tt_hz = 2.5/2*mm;
  G4double startAngle = 0.*deg;
  G4double spanningAngle = 360.*deg;

  // World
  G4double W_hz = 1.1 * m;
  G4double W_outerRadius = 10 * cm;
  G4Material* world_mat = Vacuum;

  // Detectors
  G4double Det_outerRadius = 7.5*cm;
  G4double d_hz = 0.005*cm;
  G4Material* det_mat = Vacuum;

  // Option to switch on/off checking of volumes overlaps
  G4bool checkOverlaps = true;

  auto solidWorld = new G4Tubs("solidWorld",
                            0,
                            W_outerRadius,
                            W_hz,
                            startAngle,
                            spanningAngle);

  auto logicWorld = new G4LogicalVolume(solidWorld,  // its solid
                                        world_mat,  // its material
                                        "logicWorld");  // its name

  auto physWorld = new G4PVPlacement(nullptr,  // no rotation
                                     G4ThreeVector(),  // at (0,0,0)
                                     logicWorld,  // its logical volume
                                     "World",  // its name
                                     nullptr,  // its mother  volume
                                     false,  // no boolean operation
                                     0,  // copy number
                                     checkOverlaps);  // overlaps checking


  // Tube with Local Magnetic field
  G4double Mf_length = W_hz;
  G4ThreeVector Mf_pos = G4ThreeVector();

  auto magneticSolid = new G4Tubs("magneticTub", 0., 7.5 * cm, Mf_length, 0., 360. * deg);
  fMagneticLogical = new G4LogicalVolume(magneticSolid, Vacuum, "magneticLogical");
  new G4PVPlacement(0,
                    Mf_pos,
                    fMagneticLogical,
                    "magneticPhysical",
                    logicWorld,
                    false,
                    0,
                    checkOverlaps);

  // Tube of gas with AIR
  G4double gas_length = 0.25 * m;
  G4ThreeVector gas_pos = G4ThreeVector(0, 0, 0.5 * m);

  auto gasSolid = new G4Tubs("GasTub", 0., 7.5 * cm, gas_length, 0., 360. * deg);
  auto gasLogical = new G4LogicalVolume(gasSolid, Air, "GasLogical");
  new G4PVPlacement(0,
                    gas_pos,
                    gasLogical,
                    "GasPhysical",
                    fMagneticLogical,
                    false,
                    0,
                    checkOverlaps);

  // Tungsten target (tt)
  G4Material* tt_mat = nist->FindOrBuildMaterial("G4_W");
  G4ThreeVector tt_pos = G4ThreeVector(0, 0, -W_hz + 0.1*m - tt_hz );

  auto solidtt = new G4Tubs("Tungsten",
                   innerRadius,
                   tt_outerRadius,
                   tt_hz,
                   startAngle,
                   spanningAngle);

  auto logictt = new G4LogicalVolume(solidtt,  // its solid
                                         tt_mat,  // its material
                                         "Tungsten");  // its name

  new G4PVPlacement(nullptr,  // no rotation
                    tt_pos,  // at position
                    logictt,  // its logical volume
                    "Tungsten",  // its name
                    fMagneticLogical,  // its mother  volume
                    false,  // no boolean operation
                    0,  // copy number
                    checkOverlaps);  // overlaps checking

  // Detectors
  G4ThreeVector det_pos_at = tt_pos + G4ThreeVector(0, 0, tt_hz + d_hz);
  G4ThreeVector det_pos_end = G4ThreeVector(0, 0, W_hz - 0.1*m + 0.001*cm);
  G4ThreeVector det_pos_ad = tt_pos + G4ThreeVector(0, 0, tt_hz + d_hz + 10.*cm);
  G4ThreeVector det_pos_El = G4ThreeVector(0, 0, -0.249*m);

  auto soliddet = new G4Tubs("Detector", innerRadius, Det_outerRadius, d_hz, startAngle, spanningAngle);

  // Detector after target
  auto logicdet_at = new G4LogicalVolume(soliddet, det_mat, "Detector");
  new G4PVPlacement(nullptr, det_pos_at, logicdet_at, "Detector", fMagneticLogical, false, 0, checkOverlaps);

  // Detector at the end
  auto logicdet_end = new G4LogicalVolume(soliddet, det_mat, "Detector");
  new G4PVPlacement(nullptr, det_pos_end, logicdet_end, "Detector", fMagneticLogical, false, 0, checkOverlaps);

  // Detector after adiabatic device
  auto logicdet_ad = new G4LogicalVolume(soliddet, det_mat, "Detector");
  new G4PVPlacement(nullptr, det_pos_ad, logicdet_ad, "Detector", fMagneticLogical, false, 0, checkOverlaps);

  // Detector after Electric field
  auto logicdet_El = new G4LogicalVolume(soliddet, det_mat, "Detector");
  new G4PVPlacement(nullptr, det_pos_El, logicdet_El, "Detector", fMagneticLogical, false, 0, checkOverlaps);

  // Set scoring volumes
  fScoringVolumeT = logictt;
  fScoringVolume_at = logicdet_at;
  fScoringVolume_end = logicdet_end;
  fScoringVolume_ad = logicdet_ad;
  fScoringVolume_El = logicdet_El;
  fScoringVolume_gas = gasLogical;

  // always return the physical World
  return physWorld;
}

/*void DetectorConstruction::SetFieldValue()
{
    G4UniformElectricField* elField = nullptr;
    G4ThreeVector FieldVector = {0., 0., 1000*kilovolt/cm};
    elField = new G4UniformElectricField(FieldVector);

    // Set field to the field builder
    auto fieldBuilder = G4FieldBuilder::Instance();
    fieldBuilder->SetGlobalField(elField);
}*/

void DetectorConstruction::ConstructSDandField()
{
    /*// magnetic field
    fMagneticField = new EMField();
    fFieldMgr = new G4FieldManager();
    fFieldMgr->SetDetectorField(fMagneticField);
    fFieldMgr->CreateChordFinder(fMagneticField);
    G4bool forceToAllDaughters = true;
    fMagneticLogical->SetFieldManager(fFieldMgr, forceToAllDaughters);*/

    // EM field
    fEMField = new EMField();
    auto equation = new G4EqMagElectricField(fEMField);

    /*G4FieldManager* fieldManager =
        G4TransportationManager::GetTransportationManager()->GetFieldManager();
    fieldManager->SetDetectorField(fEMField);*/

    fFieldMgr = new G4FieldManager();
    fFieldMgr->SetDetectorField(fEMField);

    G4MagIntegratorStepper* stepper = new G4ClassicalRK4(equation, 12);

    G4double minStep = 0.01 * mm;

    auto chordFinder = new G4ChordFinder((G4MagneticField*)fEMField, minStep, stepper);

    // Set accuracy parameters
    G4double deltaChord = .3 * mm;
    chordFinder->SetDeltaChord(deltaChord);

    // Maximum allowed integration error in one integration sub-step
    G4double deltaOneStep = 0.01 * mm;
    fFieldMgr->SetAccuraciesWithDeltaOneStep(deltaOneStep);

    G4double deltaIntersection = 0.1 * mm;
    fFieldMgr->SetDeltaIntersection(deltaIntersection);

    G4TransportationManager* transportManager = G4TransportationManager::GetTransportationManager();

    G4PropagatorInField* fieldPropagator = transportManager->GetPropagatorInField();

    // Limits for relative accuracy of integration
    G4double epsMin = 2.5e-7;
    G4double epsMax = 0.001;

    fieldPropagator->SetMinimumEpsilonStep(epsMin);
    fieldPropagator->SetMaximumEpsilonStep(epsMax);

    fFieldMgr->SetChordFinder(chordFinder);

    G4bool forceToAllDaughters = true;
    fMagneticLogical->SetFieldManager(fFieldMgr, forceToAllDaughters);

 /*   // Create detector field
    SetFieldValue();

    // Construct all Geant4 field objects
    auto fieldBuilder = G4FieldBuilder::Instance();
    fieldBuilder->SetFieldType(kElectroMagnetic);
    fieldBuilder->ConstructFieldSetup();*/
}
