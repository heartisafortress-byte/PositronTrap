#include "G4UserEventAction.hh"
#include <unordered_set>
#include "globals.hh"

class G4Event;
class RunAction;

/// Event action class

class EventAction : public G4UserEventAction
{
  public:
    EventAction(RunAction* runAction);
    ~EventAction() override = default;

    void BeginOfEventAction(const G4Event* event) override;
    void EndOfEventAction(const G4Event* event) override;

    void AddEdep(G4double edep) { fEdep += edep; }
    void AddNoP_at(G4int nop_at) { fNoP_at += nop_at; }
    void AddNoE_at(G4int noe_at) { fNoE_at += noe_at; }
    void AddNoP_end(G4int nop_end) { fNoP_end += nop_end; }
    void AddNoE_end(G4int noe_end) { fNoE_end += noe_end; }
    void AddNoP_ad(G4int nop_ad) { fNoP_ad += nop_ad; }
    void AddNoE_ad(G4int noe_ad) { fNoE_ad += noe_ad; }
    void AddNoP_El(G4int nop_El) { fNoP_El += nop_El; }
    void AddNoE_El(G4int noe_El) { fNoE_El += noe_El; }
    void AddNoP_gas(G4int nop_gas) { fNoP_gas += nop_gas; }

  private:
    RunAction* fRunAction = nullptr;
    G4double fEdep = 0.;
    G4int fNoP_at = 0;
    G4int fNoE_at = 0;
    G4int fNoP_end = 0;
    G4int fNoE_end = 0;
    G4int fNoP_ad = 0;
    G4int fNoE_ad = 0;
    G4int fNoP_El = 0;
    G4int fNoE_El = 0;
    G4int fNoP_gas = 0;
};

