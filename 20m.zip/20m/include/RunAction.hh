#include "G4UserRunAction.hh"
#include "G4Run.hh"

#include "G4Accumulable.hh"
#include "G4SystemOfUnits.hh"
#include "G4UnitsTable.hh"
#include "globals.hh"
#include <fstream>



class G4Run;

class RunAction : public G4UserRunAction
{
  public:
    RunAction();
    ~RunAction() override = default;

    void BeginOfRunAction(const G4Run*) override;
    void EndOfRunAction(const G4Run*) override;

    void AddEdep(G4double edep);
    void AddNoP_at(G4int nop_at);
    void AddNoE_at(G4int noe_at);
    void AddNoP_end(G4int nop_end);
    void AddNoE_end(G4int noe_end);
    void AddNoP_ad(G4int nop_ad);
    void AddNoE_ad(G4int noe_ad);
    void AddNoP_El(G4int nop_El);
    void AddNoE_El(G4int noe_El);
    void AddNoP_gas(G4int nop_gas);

    void WriteToFile(const G4Run* run) {

        G4double edep = fEdep.GetValue();
        G4int nop_at = fNoP_at.GetValue();
        G4int noe_at = fNoE_at.GetValue();
        G4int nop_end = fNoP_end.GetValue();
        G4int noe_end = fNoE_end.GetValue();
        G4int nop_ad = fNoP_ad.GetValue();
        G4int noe_ad = fNoE_ad.GetValue();
        G4int nop_El = fNoP_El.GetValue();
        G4int noe_El = fNoE_El.GetValue();
        G4int nop_gas = fNoP_gas.GetValue();

        std::ofstream Results(fResults, std::ios::app);

        if (!Results.is_open()) {
            G4cerr << "Error: Could not open file " << fResults << G4endl;
            return;
        }

        Results
            << "--------------------End of Global Run-----------------------" << G4endl
            << " Run ID: " << run->GetRunID() << G4endl
            << " Total Events: " << run->GetNumberOfEvent() << G4endl
            //<< " Particles: " << G4endl
            //<< " Energy: " << G4endl
            //<< " Target thickness: " << G4endl
            << " Energy deposited per run in tungsten target: " << G4BestUnit(edep, "Energy") << G4endl
            << " Number of e+ born: " << nop_at << G4endl
            << " Number of e- born: " << noe_at << G4endl
            << " Number of e+ escaped the trap: " << nop_end << G4endl
            << " Number of e- escaped the trap: " << noe_end << G4endl
            << " Number of e+ reached the end of adiabatic device: " << nop_ad << G4endl
            << " Number of e- reached the end of adiabatic device: " << noe_ad << G4endl
            << " Number of e+ reached the end of Electric field: " << nop_El << G4endl
            << " Number of e- reached the end of Electric field: " << noe_El << G4endl
            << " Number of e+ captured in gas: " << nop_gas << G4endl
            << "------------------------------------------------------------" << G4endl << G4endl;
    }

  private:
    G4Accumulable<G4double> fEdep = 0.;
    G4Accumulable<G4int> fNoP_at = 0;
    G4Accumulable<G4int> fNoE_at = 0;
    G4Accumulable<G4int> fNoP_end = 0;
    G4Accumulable<G4int> fNoE_end = 0;
    G4Accumulable<G4int> fNoP_ad = 0;
    G4Accumulable<G4int> fNoE_ad = 0;
    G4Accumulable<G4int> fNoP_El = 0;
    G4Accumulable<G4int> fNoE_El = 0;
    G4Accumulable<G4int> fNoP_gas = 0;
    std::string fResults;
    };

