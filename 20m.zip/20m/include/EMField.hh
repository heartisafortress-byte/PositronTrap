#include "G4ElectroMagneticField.hh"
#include "globals.hh"

#include <CLHEP/Units/SystemOfUnits.h>

class G4GenericMessenger;

class EMField : public G4ElectroMagneticField
{
  public:
    EMField();
    ~EMField() override;

    /// DoesFieldChangeEnergy() returns true.
    G4bool DoesFieldChangeEnergy() const override { return true; };

    void GetFieldValue(const G4double point[4], double* bField) const override;

};

